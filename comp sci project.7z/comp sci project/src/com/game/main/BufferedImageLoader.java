package com.game.main;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

@SuppressWarnings("unused")
public class BufferedImageLoader {
	
	BufferedImage image;
	
	public BufferedImage loadImage(String path) {
		//File img = new File(path);
		try {
			image = ImageIO.read(getClass().getResource(path));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return image;
		}

	}
	

