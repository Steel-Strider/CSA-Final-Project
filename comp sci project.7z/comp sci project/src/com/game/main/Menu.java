package com.game.main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.util.Random;

import com.game.main.Game.STATE;

public class Menu extends MouseAdapter{
	Game game;
	Handler handler;
	HUD hud;
	static boolean flag = true;
	private Random r = new Random();
	public Menu(Game game, Handler handler, HUD hud) {
		this.game = game;
		this.handler = handler;
	}
	public void mousePressed(MouseEvent e) {
		int mx = e.getX();
		int my = e.getY();
		
		//System.out.println(mx + " " + my);
		if(Game.gameState == STATE.Menu) {
		if(mouseOver(mx, my,210,150,200,64)) {
			Game.gameState = STATE.Game;
			handler.addObject(new Player(Game.WIDTH/2-32,Game.HEIGHT/2-32,ID.Player, handler));
			handler.clearEnemies();
			handler.addObject(new BasicEnemy(r.nextInt(Game.WIDTH)/2,r.nextInt(Game.HEIGHT)/2,ID.BasicEnemy, handler));
		}
		if(mouseOver(mx, my,210,350,200,64)) {
			System.exit(1);
		}
		if(mouseOver(mx, my,210,250,200,64)) {
			Game.gameState = STATE.Help;
		}
		}
		if(Game.gameState == STATE.Help && mouseOver(mx, my,25,360, 200, 64)) {
			Game.gameState = STATE.Menu;
		}
		
		if(Game.gameState == STATE.End && mouseOver(mx, my,25,360, 200, 64)) {
			Game.gameState = STATE.Menu;
		}
		if(Game.gameState == STATE.Win && mouseOver(mx, my,25,360, 200, 64)) {
			Game.gameState = STATE.Menu;
		}
	}
	
	public void mouseReleased(MouseEvent e) {
		
	}
	
	private boolean mouseOver(int mx, int my,int x, int y, int width, int height) {
		if(mx > x && mx < x + width) {
			if(my > y && my < y + height) {
				return true;
			}
			else return false;
		}
		else return false;
	}
	
	public void tick() {
		
	}
	
	public void render(Graphics g) {
		
		if(flag) {
			flag = false;
			for(int i = 0;i<40;i++)
			{
				handler.addObject(new MenuParticle(r.nextInt(Game.WIDTH)/2-50,r.nextInt(Game.HEIGHT)/2-50,ID.MenuParticle, handler));
			}
		}
				
		if(Game.gameState == STATE.Menu) {
		Font fnt = new Font("arial",1,50);
		Font fnt2 = new Font("arial",1,30);
		
		
		g.setFont(fnt);
		g.setColor(Color.white);
		g.drawString("Menu", 250, 70);
		
		g.setFont(fnt2);
		g.drawRect(210,150,200,64);
		g.drawString("Play", 280, 190);
		
		g.drawRect(210,250,200,64);
		g.drawString("Help", 280, 290);
		
		g.drawRect(210,350,200,64);
		g.drawString("Quit", 280, 390);
		}
		
		else if(Game.gameState == STATE.Help) {
			Font fnt = new Font("arial",1,50);
			Font fnt2 = new Font("arial",1,30);
			
			g.setFont(fnt);
			g.setColor(Color.white);
			g.drawString("Help", 250, 70);
			
			g.setFont(fnt2);
			g.drawString("Move around the screen using W, A, S, D",25,190);
			g.drawString("Avoid the enemies, pick up health, and", 40, 230);
			g.drawString("beat the boss to Save Mr.Grant!",90,270);
			
			g.drawRect(25,360, 200, 64);
			g.drawString("<- Back",70,400);
		}
		else if(Game.gameState == STATE.End) {
			Font fnt = new Font("arial",1,50);
			Font fnt2 = new Font("arial",1,30);
			
			g.setFont(fnt);
			g.setColor(Color.white);
			g.drawString("End", 250, 70);
			
			g.setFont(fnt2);
			g.drawString("Get up and try again, you were so close",25,190);
		
			
			g.drawRect(25,360, 200, 64);
			g.drawString("<- Retry",70,400);
		}
		else if(Game.gameState == STATE.Win) {
			Font fnt = new Font("arial",1,50);
			Font fnt2 = new Font("arial",1,30);
			
			BufferedImage grant;
			SpriteSheet ss = new SpriteSheet(Game.sprite_sheet);
			grant = ss.grabImage(3,3, 64, 64);
			
			handler.object.clear();
			g.setFont(fnt);
			g.setColor(Color.white);
			g.drawString("You saved Mr.Grant!", 80, 70);
			
			g.setFont(fnt2);
			g.drawString("Thank you for your help!",140,190);
			
			g.drawImage(grant, 295, 95,null);
		
			
			g.drawRect(25,360, 200, 64);
			g.drawString("<- Play Again",30,400);
			flag = true;
		}
		}
	}


