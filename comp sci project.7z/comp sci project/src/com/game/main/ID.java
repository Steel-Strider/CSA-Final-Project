package com.game.main;

public enum ID {
	
	Player(),
	FastEnemy(),
	BasicEnemy(),
	TrackerEnemy(),
	BossEnemy(),
	MenuParticle(),
	Pickup(),
	Trail();

}
