package com.game.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.game.main.Game.STATE;

public class HUD {
	
	public static int HEALTH = 200;
	private int greenValue = 255;
	
	private int score = 0;
	private int level = 1;
	int bossTimer = 2000;
	
	Game game;
	
	BufferedImage grant;
	
	
	public void tick() {
		HEALTH = Game.clamp(HEALTH, 0, 200);
		greenValue = Game.clamp(greenValue, 0, 255);
		greenValue = HEALTH;
		score++;
		if(level >= 10) {
			bossTimer--;
			
		}
		if(bossTimer<=0) Game.gameState = STATE.Win;
		if (Game.gameState != Game.STATE.Game) {
			score = 0;
			level = 1;
			HEALTH = 200;
		}
	}
	
	public void render(Graphics g) {
		SpriteSheet ss = new SpriteSheet(Game.sprite_sheet);
		grant = ss.grabImage(1,3, 64, 64);
		g.setColor(Color.gray);
		g.fillRect(15, 15, 200, 32);
		g.setColor(new Color(100, greenValue, 0));
		g.fillRect(15, 15, HEALTH, 32);
		g.setColor(Color.white);
		g.drawRect(15, 15, HEALTH, 32);
		
		//g.drawString("Score: " + score,10,64);
		if(level<10)g.drawString("Level: "+ level, 10,64);
		if(level >= 10) {
			g.drawString("Level: BOSS", 10,64);
			g.setColor(Color.gray);
			g.fillRect(425, 15, 200, 32);
			g.setColor(new Color(255, 0, 0));
			g.fillRect(425, 15, bossTimer/10, 32);
			g.setColor(Color.white);
			g.drawRect(425, 15, bossTimer/10, 32);
			g.drawImage(grant, 290, 05, null);
			
		}
	}
	
	public void setScore(int score) {
		this.score = score;
	}
	
	public int getScore() {
		return score;
	}
	
	public int getLevel() {
		return level;
	}
	
	public String printLevel() {
		return "" + level;
	}
	
	public void setLevel(int level) {
		this.level = level;
	}
	
	public void setHealth(int health) {
		HUD.HEALTH = health;
	}
	
	public int getHealth() {
		return HEALTH;
	}

}
