package com.game.main;

import java.util.Random;

public class Spawn {
	
	private Handler handler;
	private HUD hud;
	Game game;
	private int scoreKeep = 0;
	Random r = new Random();
	
	public Spawn(Handler handler,HUD hud) {
		this.handler = handler;
		this.hud = hud;
	}
	
	public void tick() {
		scoreKeep++;
		
		if(scoreKeep>= 500) {
			scoreKeep = 0;
			hud.setLevel(hud.getLevel()+1);
			if(hud.getLevel()>=1) handler.addObject(new HealthDrop(r.nextInt(Game.WIDTH-50),r.nextInt(Game.HEIGHT-50), ID.Pickup, handler));
			if(hud.getLevel() <=5) {
				handler.addObject(new BasicEnemy(r.nextInt(Game.WIDTH-50),r.nextInt(Game.HEIGHT-50), ID.BasicEnemy, handler));
			}
			if(hud.getLevel() >= 5 && hud.getLevel() <= 7) {
				handler.addObject(new FastEnemy(r.nextInt(Game.WIDTH-50),r.nextInt(Game.HEIGHT-50), ID.FastEnemy, handler));
			}
			if(hud.getLevel() == 8) {
				handler.addObject(new TrackerEnemy(r.nextInt(Game.WIDTH-50),r.nextInt(Game.HEIGHT-50), ID.TrackerEnemy, handler));
			}
			if(hud.getLevel() == 10) {
				handler.clearEnemies();
				handler.addObject(new BossEnemy(r.nextInt(Game.WIDTH-48),-100,ID.BossEnemy,handler));
			}
			if (Game.gameState != Game.STATE.Game) scoreKeep = 0;
		}

		}
	}
