package com.game.main;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

public class Player extends GameObject {
	Handler handler;
	
	private BufferedImage player_image;
	
	public Player(int x, int y, ID id, Handler handler) {
		super(x, y, id);
		this.handler = handler;
		
		SpriteSheet ss = new SpriteSheet(Game.sprite_sheet);
		player_image = ss.grabImage(1, 1, 32, 32);
		
	}


	public void tick() {
		x+= velX;
		y+= velY;
		
		x = Game.clamp(x, 0, Game.WIDTH-36);
		y = Game.clamp(y, 0, Game.HEIGHT-60);
		//handler.addObject(new Trail(x,y,ID.Trail,Color.white,(float) 0.1,32,32, handler));
	
		collision();
	}
	
	private void collision() {
		for(int i = 0; i<handler.object.size();i++) {
			GameObject tempObject = handler.object.get(i);
			if(tempObject.getId() == ID.BasicEnemy) {
				if(getBounds().intersects(tempObject.getBounds())) {
					//collision code
					HUD.HEALTH -= 2;
				}
			}
			if(tempObject.getId() == ID.FastEnemy || tempObject.getId() == ID.TrackerEnemy) {
				if(getBounds().intersects(tempObject.getBounds())) {
					//collision code
					HUD.HEALTH -= 3;
				}
			}
			if(tempObject.getId() == ID.BossEnemy) {
				if(getBounds().intersects(tempObject.getBounds())) {
					//collision code
					HUD.HEALTH -= 100;
				}
			}
			if(tempObject.getId() == ID.Pickup) {
				if(getBounds().intersects(tempObject.getBounds())) {
					//collision code
					HUD.HEALTH += 50;
					handler.removeObject(tempObject);
				}
			}
		}
	}


	public void render(Graphics g) {
		//g.setColor(Color.white);
		//g.fillRect(x,y,32,32);
		g.drawImage(player_image, x, y, null);

		
	}



	public Rectangle getBounds() {
		return new Rectangle(x,y,32,32);
	}
	
	

}
